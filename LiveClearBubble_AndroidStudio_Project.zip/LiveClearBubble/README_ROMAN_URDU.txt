LIVE CLEAR BUBBLE — Android Studio starter project

Yeh ZIP source project hai, ready APK nahi.

Is starter mein:
- Android app shell
- Overlay permission screen
- Screen-capture permission prompt
- Messenger-style floating bubble prototype

IMPORTANT: Bubble ka tap abhi sirf LC/ON label toggle karta hai. Yeh build doosri apps ki live video ko sharpen nahi karta. Cross-app live video enhancement ke liye screen capture, frame processing, overlay feedback-loop handling aur Oppo device testing ki zaroorat hai. Isay finished video enhancer na samjhein.

Build karne ke liye:
1. Android Studio install karein.
2. Is folder ko Android Studio mein Open karein.
3. Gradle sync complete hone dein.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).

Android SDK 35 aur internet connection required.
