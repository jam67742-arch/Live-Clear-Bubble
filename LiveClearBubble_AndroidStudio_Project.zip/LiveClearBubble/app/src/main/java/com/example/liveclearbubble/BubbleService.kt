package com.example.liveclearbubble
import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
class BubbleService:Service() {
 private var wm:WindowManager?=null
 private var view:TextView?=null
 override fun onCreate() {
  super.onCreate()
  val channel="lcb"
  if(Build.VERSION.SDK_INT>=26) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(channel,"Live Clear Bubble",NotificationManager.IMPORTANCE_LOW))
  val n=if(Build.VERSION.SDK_INT>=26) Notification.Builder(this,channel) else Notification.Builder(this)
  startForeground(1,n.setContentTitle("Live Clear Bubble").setContentText("Floating control running").setSmallIcon(android.R.drawable.ic_menu_view).build())
  wm=getSystemService(Context.WINDOW_SERVICE) as WindowManager
  view=TextView(this).apply { text="LC"; textSize=16f; setTextColor(-1); setBackgroundColor(0xff2457a6.toInt()); gravity=Gravity.CENTER; setPadding(20,15,20,15); setOnClickListener { text=if(text=="LC") "ON" else "LC" } }
  val t=if(Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
  val p=WindowManager.LayoutParams(-2,-2,t,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.END; x=20; y=180 }
  wm?.addView(view,p)
 }
 override fun onDestroy(){ view?.let{wm?.removeView(it)}; super.onDestroy() }
 override fun onBind(i:Intent?):IBinder?=null
}
