package com.example.liveclearbubble
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.activity.ComponentActivity
class MainActivity: ComponentActivity() {
 private val requestCode=4102
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(30,45,30,30) }
  box.addView(TextView(this).apply { text="Live Clear Bubble\n\nFloating bubble prototype. Real-time enhancement of other apps' video is not implemented in this starter."; textSize=18f })
  box.addView(Button(this).apply { text="Allow display over other apps"; setOnClickListener {
   if (!Settings.canDrawOverlays(this@MainActivity)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")))
  }})
  box.addView(Button(this).apply { text="Start floating bubble"; setOnClickListener {
   if (!Settings.canDrawOverlays(this@MainActivity)) Toast.makeText(this@MainActivity,"Pehle overlay permission allow karein",Toast.LENGTH_LONG).show()
   else { val mgr=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager; startActivityForResult(mgr.createScreenCaptureIntent(),requestCode) }
  }})
  setContentView(box)
 }
 @Deprecated("Compatibility callback")
 override fun onActivityResult(req:Int,res:Int,data:Intent?) {
  super.onActivityResult(req,res,data)
  if(req==requestCode && res==Activity.RESULT_OK && data!=null) {
   startForegroundService(Intent(this,BubbleService::class.java))
   Toast.makeText(this,"Floating bubble started",Toast.LENGTH_SHORT).show()
  }
 }
}
